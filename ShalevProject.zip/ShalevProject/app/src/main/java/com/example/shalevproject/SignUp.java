package com.example.shalevproject;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.text.ParseException;
import java.util.ArrayList;
public class SignUp extends AppCompatActivity {
    TextView tv_log_in;
    Button bt_register;
    EditText inputUsername, inputEmail, inputPassword,
            inputConformPassword, inputAnswer;
    Dialog registerDialog;
    ImageButton bt_show1, bt_show2;
    Spinner s_question;
    ArrayAdapter<String> adapter;
    String[] questions;
    int question_index = 0;
    String username, email, password, conform_password, answer;
    User user;
    ArrayList<User> users;
    GlobalFunctions globalFunctions;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        tv_log_in = findViewById(R.id.tv_log_in);
        bt_register = findViewById(R.id.bt_register);
        inputUsername = findViewById(R.id.inputUsername);
        inputEmail = findViewById(R.id.inputEmail);
        inputPassword = findViewById(R.id.inputPassword);
        inputConformPassword = findViewById(R.id.inputConformPassword);
        inputAnswer = findViewById(R.id.inputAnswer);
        s_question = findViewById(R.id.s_question);
        bt_show1 = findViewById(R.id.bt_show1);
        bt_show2 = findViewById(R.id.bt_show2);
        globalFunctions = new GlobalFunctions(getApplicationContext());
        registerDialog = new Dialog(this);
        questions = globalFunctions.getQuestions();
//set input type of password
        inputPassword.setInputType(InputType.TYPE_CLASS_TEXT |
                InputType.TYPE_TEXT_VARIATION_PASSWORD);
        inputConformPassword.setInputType(InputType.TYPE_CLASS_TEXT |
                InputType.TYPE_TEXT_VARIATION_PASSWORD);
// Click for login
        tv_log_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(v.getContext(), Login.class));
            }
        });
// read users

//Create spinner for questions
        adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, questions);
        s_question.setAdapter(adapter);
        s_question.setOnItemSelectedListener(new
                                                     AdapterView.OnItemSelectedListener() {
                                                         @Override
                                                         public void onItemSelected(AdapterView<?> parent, View view,
                                                                                    int position, long id) {
                                                             question_index = position;
                                                         }
                                                         @Override
                                                         public void onNothingSelected(AdapterView<?> parent) { }
                                                     });
    }
    public void signUp(View view) {
        username = String.valueOf(inputUsername.getText());
        email = String.valueOf(inputEmail.getText());
        password = String.valueOf(inputPassword.getText());
        conform_password =
                String.valueOf(inputConformPassword.getText());
        answer = String.valueOf(inputAnswer.getText());
        String EMAIL_REGEX =
                "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
//The ifs to check inputs
        if(username.equals("")){
            inputUsername.setError("This field must be filled");
        }
        else if(globalFunctions.checkUserExist(username, users) ||
                username.equals(GlobalFunctions.GUEST)){
            inputUsername.setError("This username already exist");
        }
        else if(email.equals("")){
            inputEmail.setError("This field must be filled");
        }
        else if(!email.matches(EMAIL_REGEX)){
            inputEmail.setError("This is invalid email format");
        }
        else if(password.equals("")){
            inputPassword.setError("This field must be filled");
        }
        else if(!password.equals(conform_password)){
            inputConformPassword.setError("The passwords must be equal");
        }
        else if(answer.equals("")){
            inputAnswer.setError("This field must be filled");
        }
        else{
            globalFunctions.writeUserToDB(getLastUserId() + 1, username,
                    email, password, question_index, answer);
            user = new User(getLastUserId() + 1, username, email,
                    password, question_index, answer);
            openRegisterDialog();
        }
    }
    //Ask user if he want to auto login in the app
    private void openRegisterDialog() {
        registerDialog.setContentView(R.layout.registerdialog);
        registerDialog.getWindow().setBackgroundDrawable(new
                ColorDrawable(0));
        registerDialog.setCanceledOnTouchOutside(false);
//Button to accept
        Button bt_accept = registerDialog.findViewById(R.id.bt_accept);
        bt_accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                globalFunctions.saveUserInFile(user);
                Intent send = new Intent(v.getContext(),
                        MainActivity.class);
                send.putExtra("user", user);
                startActivity(send);
            }
        });
//Button to refuse
        Button bt_refuse = registerDialog.findViewById(R.id.bt_refuse);
        bt_refuse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent send = new Intent(v.getContext(),
                        MainActivity.class);
                send.putExtra("user", user);
                startActivity(send);
            }
        });
        registerDialog.show();
    }
    public void back(View view) {
        startActivity(new Intent(this, MainActivity.class));
    }
    public void showPass(View view) {
        if(inputPassword.getInputType() == (InputType.TYPE_CLASS_TEXT |
                InputType.TYPE_TEXT_VARIATION_PASSWORD)){
            inputPassword.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);

        }
        else{
            inputPassword.setInputType(InputType.TYPE_CLASS_TEXT |
                    InputType.TYPE_TEXT_VARIATION_PASSWORD);

        }
    }
    //Change the show status of password
    public void showConPass(View view) {
        if(inputConformPassword.getInputType() ==
                (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD)){
            inputConformPassword.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);

        }
        else{
            inputConformPassword.setInputType(InputType.TYPE_CLASS_TEXT
                    | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        }
    }
    private int getLastUserId(){
        if(users.size() == 0){
            return 0;
        }
        return users.get(users.size() - 1).getId();
    }
}


